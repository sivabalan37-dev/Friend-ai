package com.thala.ai

import java.util.Locale

enum class ActionType { OPEN_APP, SET_TIMER, CALENDAR_EVENT, UNKNOWN }

data class CommandResult(
    val action: ActionType,
    val appName: String? = null,
    val timerSeconds: Int? = null,
    val eventTitle: String? = null,
    val reply: String
)

/**
 * Pure on-device, keyword-based command parser.
 * No network calls and no external AI API — everything here runs locally.
 * The Tamil word lists below are a starting point; add more phrasing as you test with real speech.
 */
object CommandProcessor {

    private val openWords = listOf("open", "launch", "start", "திற", "ஆரம்பி")
    private val timerWords = listOf("timer", "டைமர்", "அலாரம்")
    private val calendarWords = listOf(
        "calendar", "event", "schedule", "appointment", "reminder",
        "கலெண்டர்", "நிகழ்வு"
    )

    fun process(rawInput: String): CommandResult {
        val input = rawInput.trim()
        val lower = input.lowercase(Locale.getDefault())

        return when {
            timerWords.any { lower.contains(it) } -> parseTimer(input, lower)
            calendarWords.any { lower.contains(it) } -> parseCalendar(input)
            openWords.any { lower.contains(it) } -> parseOpenApp(input)
            else -> CommandResult(
                ActionType.UNKNOWN,
                reply = "I didn't catch that. Try 'open camera', 'set timer for 5 minutes', or 'add event meeting'."
            )
        }
    }

    private fun parseOpenApp(input: String): CommandResult {
        var appName = input
        for (w in openWords) {
            appName = appName.replace(Regex("(?i)$w"), "")
        }
        appName = appName.trim()
        return CommandResult(
            ActionType.OPEN_APP,
            appName = appName,
            reply = if (appName.isNotEmpty()) "Opening $appName" else "Which app should I open?"
        )
    }

    private fun parseTimer(input: String, lower: String): CommandResult {
        val amount = Regex("\\d+").find(input)?.value?.toIntOrNull() ?: 1
        val seconds = when {
            lower.contains("hour") || lower.contains("மணி") -> amount * 3600
            lower.contains("sec") || lower.contains("வினாடி") -> amount
            else -> amount * 60 // default unit is minutes, also matches "நிமிடம்"
        }
        val unitLabel = when {
            lower.contains("hour") || lower.contains("மணி") -> "hour(s)"
            lower.contains("sec") || lower.contains("வினாடி") -> "second(s)"
            else -> "minute(s)"
        }
        return CommandResult(
            ActionType.SET_TIMER,
            timerSeconds = seconds,
            reply = "Setting a timer for $amount $unitLabel"
        )
    }

    private fun parseCalendar(input: String): CommandResult {
        var title = input
        for (w in calendarWords) {
            title = title.replace(Regex("(?i)$w"), "")
        }
        for (w in listOf("add", "set", "create", "new", "சேர்", "உருவாக்கு")) {
            title = title.replace(Regex("(?i)$w"), "")
        }
        title = title.trim().ifEmpty { "New event" }
        return CommandResult(
            ActionType.CALENDAR_EVENT,
            eventTitle = title,
            reply = "Opening calendar to add \"$title\""
        )
    }
}
