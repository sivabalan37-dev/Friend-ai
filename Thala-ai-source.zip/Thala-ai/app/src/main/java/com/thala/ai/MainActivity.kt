package com.thala.ai

import android.Manifest
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.AlarmClock
import android.provider.CalendarContract
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import java.util.Locale

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {

    private lateinit var tts: TextToSpeech
    private lateinit var responseView: TextView
    private lateinit var inputField: EditText

    private val speechLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val text = result.data
                ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                ?.firstOrNull()
            if (!text.isNullOrBlank()) {
                inputField.setText(text)
                handleCommand(text)
            }
        }
    }

    private val micPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) startListening() else respond("I need microphone permission for voice commands.")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tts = TextToSpeech(this, this)
        responseView = findViewById(R.id.responseText)
        inputField = findViewById(R.id.commandInput)

        findViewById<Button>(R.id.sendButton).setOnClickListener {
            val text = inputField.text.toString()
            if (text.isNotBlank()) handleCommand(text)
        }

        findViewById<Button>(R.id.micButton).setOnClickListener {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                == PackageManager.PERMISSION_GRANTED
            ) {
                startListening()
            } else {
                micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
            }
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            // Default to English for now; swap in a Tamil Locale once a Tamil TTS voice
            // is confirmed on-device (availability varies by phone).
            tts.language = Locale.US
        }
    }

    private fun startListening() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak a command")
        }
        try {
            speechLauncher.launch(intent)
        } catch (e: ActivityNotFoundException) {
            respond("Speech recognition isn't available on this device.")
        }
    }

    private fun handleCommand(text: String) {
        val result = CommandProcessor.process(text)
        respond(result.reply)
        when (result.action) {
            ActionType.OPEN_APP -> result.appName?.let { openApp(it) }
            ActionType.SET_TIMER -> result.timerSeconds?.let { setTimer(it) }
            ActionType.CALENDAR_EVENT -> result.eventTitle?.let { createCalendarEvent(it) }
            ActionType.UNKNOWN -> {}
        }
    }

    private fun respond(message: String) {
        responseView.text = message
        tts.speak(message, TextToSpeech.QUEUE_FLUSH, null, null)
    }

    private fun openApp(appName: String) {
        val pm = packageManager
        val match = pm.getInstalledApplications(PackageManager.GET_META_DATA)
            .firstOrNull { pm.getApplicationLabel(it).toString().contains(appName, ignoreCase = true) }
        val launchIntent = match?.let { pm.getLaunchIntentForPackage(it.packageName) }
        if (launchIntent != null) {
            startActivity(launchIntent)
        } else {
            respond("I couldn't find an app called $appName")
        }
    }

    private fun setTimer(seconds: Int) {
        val intent = Intent(AlarmClock.ACTION_SET_TIMER).apply {
            putExtra(AlarmClock.EXTRA_LENGTH, seconds)
            putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            putExtra(AlarmClock.EXTRA_MESSAGE, "Thala timer")
        }
        try {
            startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            respond("No clock app found to set the timer.")
        }
    }

    private fun createCalendarEvent(title: String) {
        val intent = Intent(Intent.ACTION_INSERT).apply {
            data = CalendarContract.Events.CONTENT_URI
            putExtra(CalendarContract.Events.TITLE, title)
        }
        try {
            startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            respond("No calendar app found.")
        }
    }

    override fun onDestroy() {
        tts.shutdown()
        super.onDestroy()
    }
}
